//Create , editing and deliting from catalog and rendering ofer by ofer

import { get, post, put, del } from "./api.js";
//линковете ни са даден по условия- byId за offer details, edit and delete 
const endpoins = {
    catalog: '/data/albums?sortBy=_createdOn%20desc',
    //byUserId: userId => `/data/books?where=_ownerId%3D%22${userId}%22&sortBy=_createdOn%20desc`,
    create: '/data/albums',  
    byId: '/data/albums/'
}
//така взимаме всички книги
export async function getAllAbums() {
    return get(endpoins.catalog);
}

export async function getById(id) {
    return get(endpoins.byId + id);
}

export async function createAlbum(data) {
    return post(endpoins.create, data);
}

export async function updateAlbum(id, data) {
    return put(endpoins.byId + id, data);
}

export async function deleteAlbum(id) {
    return del(endpoins.byId + id);
}


export async function getMyAlbums(userId) {

    return get(`/data/books?where=_ownerId%3D%22${userId}%22&sortBy=_createdOn%20desc`);
}


